## 欢迎来到 Cloud Studio

在这里，您可以方便的使用您的专用主机进行开发。

我们为您准备了一个 Java 小示例，通过一个 spring boot 的 demo 代码，来展示 Java 环境的使用。

1. 在终端直接运行 `mvn spring-boot:run` 启动服务。(第一次运行时需要下载依赖，可能会花较长时间，请耐心等待)

![](https://dn-coding-net-production-pp.codehub.cn/707e8cdc-1133-4337-bc9e-3edc0e58445f.jpg)

2. 完全启动之后，在右边的【访问链接】侧边栏中将端口号改为 8080 并点击旁边的【+】
，生成 8080 端口的访问链接，点击就可以打开示例页面了。

![](https://dn-coding-net-production-pp.codehub.cn/47f07a4f-7b50-4f28-bb56-90570ea01799.jpg)