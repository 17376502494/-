package com.coding.studiodemo.annotation;

public @interface Role {
    String value() default "";
}

