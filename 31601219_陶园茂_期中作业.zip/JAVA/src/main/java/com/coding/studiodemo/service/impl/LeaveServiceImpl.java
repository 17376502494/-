package com.coding.studiodemo.service.impl;

import com.coding.studiodemo.domain.dao.LeaveRepository;
import com.coding.studiodemo.domain.entity.Leaves;
import com.coding.studiodemo.service.LeaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service()
public class LeaveServiceImpl implements LeaveService {

    @Autowired
    private LeaveRepository leaveRepository;

    @Override
//    @CachePut(value = "leaves",key = "#leaves.Lid")
    public void create(Leaves leaves) {
        leaveRepository.save(leaves);
    }

    @Override
    public Leaves getUserStartLeave(Long id, String state) {
        return leaveRepository.findByIdAndState(id,state);
    }

    @Override
    public List<Leaves> getUserLeave(Long id) {
        return leaveRepository.findLeave(id);
    }

    @Override
    public List<Leaves> getAllUserStartLeave(String state) {
        return leaveRepository.findStartLeave(state);
    }

    @Override
    public List<Leaves> getAllUserLeave() {
        return leaveRepository.findAll();
    }
}
