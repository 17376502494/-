package com.coding.studiodemo.controller;

import com.coding.studiodemo.annotation.PassToken;
import com.coding.studiodemo.annotation.UserLoginToken;
import com.coding.studiodemo.config.Hashkit;
import com.coding.studiodemo.domain.entity.User;
import com.coding.studiodemo.service.UserService;
import com.coding.studiodemo.common.R;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.jws.WebParam;
import javax.validation.Valid;
import java.util.*;


@RestController
@RequestMapping(value = "/users")
public class UserController {
    @Autowired
    UserService service;

//    @RequestMapping(value = "/",method = RequestMethod.GET)
//
//    public R<List<User>> getUserList(){
//        return R.data(service.getAllUser());
//    }
//
//    @RequestMapping(value = "/",method = RequestMethod.POST)
//    public R<String> postUser(@ModelAttribute User user){
//        service.create(user);
//        return R.success("success");
//    }

//    @RequestMapping(value = "/login",method = RequestMethod.POST)
//    public R<String> loginUser(@RequestParam String name,@RequestParam String password){
//        User user=service.getUser(name,password);
//        return user==null?R.fail("用户不存在或密码错误"):R.Loginsuccess(user);
//    }


    @UserLoginToken
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public R<List<User>> getUserList(){
        return R.data(service.getAllUser());
    }



//    @UserLoginToken
//    @RequestMapping(value = "/",method = RequestMethod.POST)
//    public R<String> postUser(@ModelAttribute User user){
//        service.create(user);
//        return R.success("success");
//    }

//    @UserLoginToken
//    @RequestMapping(value = "/",method = RequestMethod.POST)
//    public R<String> postUser(@ModelAttribute User user){
//        if (StringUtils.isEmpty(user.getName())){
//            throw new NullPointerException("用户名不能为空");
//        }
//        service.create(user);
//        return R.success("success");
//    }

    @UserLoginToken
    @RequestMapping(value = "/",method = RequestMethod.POST)
    public R<String> postUser(@Valid @ModelAttribute User user){
        user.setSalt(Hashkit.generateSalt(8));
        user.setPassword(Hashkit.md5(user.getPassword()+user.getSalt()));
        service.create(user);
        return R.success("success");
    }

    @PassToken
    @RequestMapping(value = "/login",method = RequestMethod.POST)
    public R<String> loginUser(@RequestParam String name,@RequestParam String password){
        User user=service.getUser(name);
        if(user==null){
            return R.fail("用户不存在");
        }
        return user.getPassword().equals(Hashkit.md5(password+user.getSalt()))?R.Loginsuccess(user):R.fail("密码错误");
    }

//    @PassToken
//    @RequestMapping(value = "/login",method = RequestMethod.POST)
//    public R<String> loginUser(@RequestParam String name,@RequestParam String password){
//        User user=service.getUser(name,password);
//        return user==null?R.fail("用户名不存在或密码错误"):R.Loginsuccess(user);
//    }



//    @RequestMapping(value = "/{id}",method = RequestMethod.GET)
//    public R<User> getUser(@PathVariable Long id){
//        return R.data(service.getUser(id));
//    }
//
//    @RequestMapping(value = "/{id}",method = RequestMethod.PUT)
//    public R<String> putUser(@PathVariable Long id,@ModelAttribute User user){
//        service.update(id,user.getName(),user.getAge());
//        return R.success("success");
//    }
//    @RequestMapping(value = "/{id}",method = RequestMethod.DELETE)
//    public R<String> deleteUser(@PathVariable Long id){
//        service.deleteById(id);
//        return R.success("success");
//    }
}
