package com.coding.studiodemo.service;

import com.coding.studiodemo.domain.entity.User;

import java.util.List;
import java.util.Map;

public interface UserService {

    void create(User user);

    void update(User user);

    void deleteById(long id);

    List<User> getAllUser();

    User getUser(long id);

    void deleteAllUsers();

    User getUser(String name,String password);

    User getUser(String name);

}
