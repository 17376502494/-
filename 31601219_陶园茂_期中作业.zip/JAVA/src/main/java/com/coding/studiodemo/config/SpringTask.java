package com.coding.studiodemo.config;

import com.coding.studiodemo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class SpringTask {
//    @Autowired
//    UserService userService;
//    @Async
//    @Scheduled(cron = "0/1 * * * * *")
//    public void scheduledl() throws InterruptedException{
//        System.out.println(LocalDateTime.now()+"\tTome的邮箱是"+userService.getUser("ti").getEmail());
//    }
}
