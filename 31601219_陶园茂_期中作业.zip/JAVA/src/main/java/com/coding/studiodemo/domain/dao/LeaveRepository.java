package com.coding.studiodemo.domain.dao;

import com.coding.studiodemo.domain.entity.Leaves;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LeaveRepository  extends JpaRepository<Leaves,Long> {

    @Query("from Leaves L where L.id=:id")
    List<Leaves>  findLeave(@Param("id") Long id);

    @Query("from Leaves L where L.state=:state")
    List<Leaves>  findStartLeave(@Param("state") String state);

    @Query("from Leaves L where L.id=:id and L.state=:state")
    Leaves findByIdAndState(@Param("id") Long id,@Param("state") String state);

}
