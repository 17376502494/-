package com.coding.studiodemo.controller;

import com.coding.studiodemo.annotation.Role;
import com.coding.studiodemo.annotation.UserLoginToken;
import com.coding.studiodemo.common.R;
import com.coding.studiodemo.domain.entity.Leaves;
import com.coding.studiodemo.domain.entity.User;
import com.coding.studiodemo.service.LeaveService;
import com.coding.studiodemo.service.UserService;
import com.coding.studiodemo.service.impl.LeaveServiceImpl;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;


@RestController
@RequestMapping(value = "/leaves")
public class LeaveController {

    @Autowired
    LeaveServiceImpl leaveService;

    @Autowired
    UserService userService;

    /**
     * 发起请假
     */
    @UserLoginToken
    @RequestMapping(value = "/",method = RequestMethod.POST)
    public R<String> postLeave(@Valid @ModelAttribute Leaves leaves, HttpServletRequest httpServletRequest){
        //获取Token
        String token = httpServletRequest.getHeader("Token");
        //通过token获取当前用户的id
        Jws<Claims> jwt = Jwts.parser().setSigningKey(R.KEY).parseClaimsJws(token);
        Long userid = jwt.getBody().get("id",Long.class);
        User user=userService.getUser(userid);
        leaves.setId(userid);
        leaves.setUsername(user.getName());
        leaves.setState("发起");
        leaveService.create(leaves);
        return R.success("请假已发起，等待管理员审批！");
    }

    /**
     * 管理员审批请假单
     */
    @UserLoginToken
    @Role("admin")
    @RequestMapping(value = "/{id}",method = RequestMethod.PUT)
    public R<String> updateLeave(@PathVariable Long id, @RequestParam String state, @RequestParam String remark, HttpServletRequest httpServletRequest){
        //获取Token
        String token = httpServletRequest.getHeader("Token");
        //通过id和请假单状态查询请假单
        Leaves leaves = leaveService.getUserStartLeave(id,"发起");
        leaves.setState(state);
        leaves.setRemark(remark);
        //通过token获取当前管理员id
        Jws<Claims> jwt = Jwts.parser().setSigningKey(R.KEY).parseClaimsJws(token);
        Long adminid = jwt.getBody().get("id",Long.class);
        User user=userService.getUser(adminid);
        leaves.setAdminid(user.getId());
        leaves.setAdminname(user.getName());
        if(state.equals("审批通过")) {
            leaveService.create(leaves);
            return R.success("请假单审批成功!");
        }else if(state.equals("审批不通过")){
            leaveService.create(leaves);
            return R.success("请假单审批成功!");
        }
        return R.fail("请重新审批请假单！！");
    }

    /**
     * 获取当前用户所有请假单列表
     */
    @UserLoginToken
    @RequestMapping(value = "/{id}",method = RequestMethod.GET)
    public R<List<Leaves>> getUserLeaveList(@PathVariable Long id){
        return R.data(leaveService.getUserLeave(id));
    }

    /**
     * 获取所有用户的发起请假列表
     */
    @UserLoginToken
    @Role("admin")
    @RequestMapping(value = "/start",method = RequestMethod.GET)
    public R<List<Leaves>> getAllUserStartLeaveList(){
        return R.data(leaveService.getAllUserStartLeave("发起"));
    }

    /**
     * 获取所有用户的所有请假列表
     */
    @UserLoginToken
    @Role("admin")
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public R<List<Leaves>> getAllUserLeaveList(){
        return R.data(leaveService.getAllUserLeave());
    }

}
